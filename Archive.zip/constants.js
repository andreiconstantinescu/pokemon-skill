var SKILL_NAME = 'The Pokédex'
var APP_ID = undefined;

module.exports = {
  SKILL_NAME,
  APP_ID
}
